print('test')
print('проверка git pull')
print('проверка git fetch')

a = 'Переменная '
b = 'для '
c = 'коммита.'

print('New UI feature')